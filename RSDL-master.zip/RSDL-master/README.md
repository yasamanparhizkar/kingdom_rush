RSDL
===
a SDL2 wrapper

[![Travis (.org)](https://travis-ci.com/UTAP/RSDL.svg)](https://travis-ci.com/UTAP/RSDL)
[![code style: LLVM](https://img.shields.io/badge/code_style-LLVM-brightgreen.svg)](https://llvm.org/docs/CodingStandards.html)

See [Wiki](../../wiki) for [Documentation](../../wiki/Documentation) and [Installation Guide](../../wiki/Installation).
